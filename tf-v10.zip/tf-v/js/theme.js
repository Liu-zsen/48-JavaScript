
var isP = document.getElementsByClassName('is-placemiddle')[0];
var mText = document.getElementsByClassName('mint-toast-text')[0];

(function(){
    var close = document.getElementsByClassName('clear');
    var IptVal = [...document.getElementsByTagName('input')];
    IptVal.forEach((v,i) => {
        clear(v,i) 
    });

    function clear(v,i){

        if(!close[i])return;
        v.onkeyup = function(){
            if(v.value !== ""){
                close[i].style.display = "block";
            }
        };
        close[i].onclick = function (){
            v.value = '';
            close[i].style.display = "none";
        }
    }

})();

//页面刷新
$(function () {
    var isPageHide = false;
    window.addEventListener('pageshow', function () {
        if (isPageHide) {
            window.location.reload();
        }
    });
    window.addEventListener('pagehide', function () {
        isPageHide = true;
    });
});

function showRes (){
    isP.classList.toggle('is-hide')
    setTimeout(function(){
        isP.classList.toggle('is-hide')
    },1000)
}

//封装过期控制代码
function setLocalStorage(key, value) {
    var curtime = new Date().getTime(); // 获取当前时间 ，转换成JSON字符串序列
    var valueDate = JSON.stringify({
        val: value,
        timer: curtime
    });
    try {
        localStorage.setItem(key, valueDate);
    } catch(e) {
        /*if(e.name === 'QUOTA_EXCEEDED_ERR' || e.name === 'NS_ERROR_DOM_QUOTA_REACHED') {
            console.log("Error: 本地存储超过限制");
            localStorage.clear();
        } else {
            console.log("Error: 保存到本地存储失败");
        }*/

        if(isQuotaExceeded(e)) {
            console.log("Error: 本地存储超过限制");
            localStorage.clear();
        } else {
            console.log("Error: 保存到本地存储失败");
        }
    }
}

function isQuotaExceeded(e) {
    var quotaExceeded = false;
    if(e) {
        if(e.code) {
            switch(e.code) {
                case 22:
                    quotaExceeded = true;
                    break;
                case 1014: // Firefox
                    if(e.name === 'NS_ERROR_DOM_QUOTA_REACHED') {
                        quotaExceeded = true;
                    }
                    break;
            }
        } else if(e.number === -2147024882) { // IE8
            quotaExceeded = true;
        }
    }
    return quotaExceeded;
}

function getLocalStorage(key) {
    var exp = 60 * 60 * 1000 * 8; //   // 8小时
    if(localStorage.getItem(key)) {
        var vals = localStorage.getItem(key); // 获取本地存储的值
        var dataObj = JSON.parse(vals); // 将字符串转换成JSON对象
        // 如果(当前时间 - 存储的元素在创建时候设置的时间) > 过期时间
        var isTimed = (new Date().getTime() - dataObj.timer) > exp;
        console.log(exp, new Date().getTime() - dataObj.timer);

        if(isTimed) {

            mText.innerHTML = "已过期,请重新登录";
            showRes();
            setTimeout(function(){
                localStorage.clear();
                location.href = "index.html"
            },1000);
            return null;
        } else {
            var newValue = dataObj.val;
        }
        return newValue;
    } else {
        return null;
    }
}
var localKey = getLocalStorage('tokenT');

//MD5加密
function getmd5(n){
    passMd5 = md5(n);
}
